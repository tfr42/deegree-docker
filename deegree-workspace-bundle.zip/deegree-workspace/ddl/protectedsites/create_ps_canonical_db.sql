-- as user postgres
CREATE DATABASE ps_canonical
  WITH OWNER = deegree
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'en_US.utf8'
       LC_CTYPE = 'en_US.utf8'
       CONNECTION LIMIT = -1;

COMMENT ON DATABASE ps_canonical
  IS 'Protected Sites - canonical schema';

GRANT ALL ON SCHEMA public TO deegree;
GRANT CONNECT ON DATABASE ps_canonical TO deegree;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO deegree;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public to deegree;

-- \c ps_canonical
CREATE EXTENSION IF NOT EXISTS postgis;