-- as user postgres
CREATE DATABASE ps_canonical3_3
  WITH OWNER = deegree
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'en_US.utf8'
       LC_CTYPE = 'en_US.utf8'
       CONNECTION LIMIT = -1;

COMMENT ON DATABASE ps_canonical3_3
  IS 'Protected Sites - canonical schema for deegree 3_3';

GRANT ALL ON SCHEMA public TO deegree;
GRANT CONNECT ON DATABASE ps_canonical3_3 TO deegree;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO deegree;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public to deegree;

-- \c ps_canonical3_3
CREATE EXTENSION IF NOT EXISTS postgis;

-- as user deegree
CREATE TABLE gn_namedplace (
    attr_gml_id text,
    gml_identifier text,
    gml_identifier_attr_codespace text,
    gn_beginlifespanversion timestamp,
    gn_beginlifespanversion_attr_nilreason text,
    gn_beginlifespanversion_attr_xsi_nil boolean,
    gn_endlifespanversion timestamp,
    gn_endlifespanversion_attr_nilreason text,
    gn_endlifespanversion_attr_xsi_nil boolean,
    gn_geometry_attr_nilreason text,
    gn_geometry_attr_gml_remoteschema text,
    gn_geometry_attr_owns boolean,
    gn_inspireid_base_identifier_base_localid text,
    gn_inspireid_base_identifier_base_namespace text,
    gn_inspireid_base_identifier_base_versionid text,
    gn_inspireid_base_identifier_base_versionid_attr_nilreason text,
    gn_inspireid_base_identifier_base_versionid_attr_xsi_nil boolean,
    gn_leastdetailedviewingresolution_attr_nilreason text,
    gn_leastdetailedviewingresolution_attr_owns boolean,
    gn_leastdetailedviewingresolution_attr_xsi_nil boolean,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_42 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_43 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_44 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_45 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_46 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_47 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_48 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_49 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_50 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_52 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_53 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_55 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_e_56 integer,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_d_58 text,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_d_59 numeric,
    gn_leastdetailedviewingresolution_gmd_md_resolution_gmd_d_60 text,
    gn_mostdetailedviewingresolution_attr_nilreason text,
    gn_mostdetailedviewingresolution_attr_owns boolean,
    gn_mostdetailedviewingresolution_attr_xsi_nil boolean,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_62 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_63 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_64 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_65 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_66 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_67 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_68 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_69 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_70 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_72 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_73 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_75 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_eq_76 integer,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_di_78 text,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_di_79 numeric,
    gn_mostdetailedviewingresolution_gmd_md_resolution_gmd_di_80 text,
    CONSTRAINT gn_namedplace_pkey PRIMARY KEY (attr_gml_id)
);
SELECT ADDGEOMETRYCOLUMN('', 'gn_namedplace','gn_geometry_value','0','GEOMETRY', 2);
CREATE TABLE gn_namedplace_gn_localtype (
    id serial PRIMARY KEY,
    parentfk text NOT NULL REFERENCES gn_namedplace ON DELETE CASCADE,
    num integer not null,
    attr_xlink_type text,
    attr_xlink_href text,
    attr_xlink_role text,
    attr_xlink_arcrole text,
    attr_xlink_title text,
    attr_xlink_show text,
    attr_xlink_actuate text,
    attr_uuidref text,
    attr_gco_nilreason text,
    attr_xsi_nil boolean,
    gmd_localisedcharacterstring text,
    gmd_localisedcharacterstring_attr_id text,
    gmd_localisedcharacterstring_attr_locale text
);
CREATE TABLE gn_namedplace_gn_name (
    id serial PRIMARY KEY,
    parentfk text NOT NULL REFERENCES gn_namedplace ON DELETE CASCADE,
    num integer not null,
    gn_geographicalname_gn_language text,
    gn_geographicalname_gn_language_attr_nilreason text,
    gn_geographicalname_gn_language_attr_xsi_nil boolean,
    gn_geographicalname_gn_nativeness_attr_owns boolean,
    gn_geographicalname_gn_nativeness_attr_nilreason text,
    gn_geographicalname_gn_nativeness_attr_gml_remoteschema text,
    gn_geographicalname_gn_nativeness_attr_xsi_nil boolean,
    gn_geographicalname_gn_nativeness_fk text,
    gn_geographicalname_gn_nativeness_href text,
    gn_geographicalname_gn_namestatus_attr_owns boolean,
    gn_geographicalname_gn_namestatus_attr_nilreason text,
    gn_geographicalname_gn_namestatus_attr_gml_remoteschema text,
    gn_geographicalname_gn_namestatus_attr_xsi_nil boolean,
    gn_geographicalname_gn_namestatus_fk text,
    gn_geographicalname_gn_namestatus_href text,
    gn_geographicalname_gn_sourceofname text,
    gn_geographicalname_gn_sourceofname_attr_nilreason text,
    gn_geographicalname_gn_sourceofname_attr_xsi_nil boolean,
    gn_geographicalname_gn_pronunciation_attr_nilreason text,
    gn_geographicalname_gn_pronunciation_attr_xsi_nil boolean,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_81 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_82 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_83 boolean,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_84 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_85 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_86 boolean,
    gn_geographicalname_gn_grammaticalgender_attr_owns boolean,
    gn_geographicalname_gn_grammaticalgender_attr_nilreason text,
    gn_geographicalname_gn_grammaticalgender_attr_gml_remoteschema text,
    gn_geographicalname_gn_grammaticalgender_attr_xsi_nil boolean,
    gn_geographicalname_gn_grammaticalgender_fk text,
    gn_geographicalname_gn_grammaticalgender_href text,
    gn_geographicalname_gn_grammaticalnumber_attr_owns boolean,
    gn_geographicalname_gn_grammaticalnumber_attr_nilreason text,
    gn_geographicalname_gn_grammaticalnumber_attr_gml_remoteschema text,
    gn_geographicalname_gn_grammaticalnumber_attr_xsi_nil boolean,
    gn_geographicalname_gn_grammaticalnumber_fk text,
    gn_geographicalname_gn_grammaticalnumber_href text
);
CREATE TABLE gn_namedplace_gn_name_gn_geographicalname_gn_spelling (
    id serial PRIMARY KEY,
    parentfk integer NOT NULL REFERENCES gn_namedplace_gn_name ON DELETE CASCADE,
    num integer not null,
    gn_geographicalname_gn_spellingofname_gn_text text,
    gn_geographicalname_gn_spellingofname_gn_script text,
    gn_geographicalname_gn_spellingofname_gn_script_attr_nilreason text,
    gn_geographicalname_gn_spellingofname_gn_script_attr_xsi_nil boolean,
    gn_geographicalname_gn_spellingofname_gn_transliterationscheme text,
    gn_geographicalname_gn_spellingofname_gn_transliterations_87 text,
    gn_geographicalname_gn_spellingofname_gn_transliterations_88 boolean
);
CREATE TABLE gn_namedplace_gn_relatedspatialobject (
    id serial PRIMARY KEY,
    parentfk text NOT NULL REFERENCES gn_namedplace ON DELETE CASCADE,
    num integer not null,
    attr_nilreason text,
    attr_xsi_nil boolean,
    base_identifier_base_localid text,
    base_identifier_base_namespace text,
    base_identifier_base_versionid text,
    base_identifier_base_versionid_attr_nilreason text,
    base_identifier_base_versionid_attr_xsi_nil boolean
);
CREATE TABLE gn_namedplace_gn_type (
    id serial PRIMARY KEY,
    parentfk text NOT NULL REFERENCES gn_namedplace ON DELETE CASCADE,
    num integer not null,
    attr_owns boolean,
    attr_nilreason text,
    attr_gml_remoteschema text,
    attr_xsi_nil boolean,
    fk text,
    href text
);
CREATE TABLE ps_protectedsite (
    attr_gml_id text,
    gml_identifier text,
    gml_identifier_attr_codespace text,
    ps_geometry_attr_nilreason text,
    ps_geometry_attr_gml_remoteschema text,
    ps_geometry_attr_owns boolean,
    ps_inspireid_base_identifier_base_localid text,
    ps_inspireid_base_identifier_base_namespace text,
    ps_inspireid_base_identifier_base_versionid text,
    ps_inspireid_base_identifier_base_versionid_attr_nilreason text,
    ps_inspireid_base_identifier_base_versionid_attr_xsi_nil boolean,
    ps_legalfoundationdate timestamp,
    ps_legalfoundationdate_attr_nilreason text,
    ps_legalfoundationdate_attr_xsi_nil boolean,
    CONSTRAINT ps_protectedsite_pkey PRIMARY KEY (attr_gml_id)
);
SELECT ADDGEOMETRYCOLUMN('', 'ps_protectedsite','ps_geometry_value','0','GEOMETRY', 2);
CREATE TABLE ps_protectedsite_ps_sitedesignation (
    id serial PRIMARY KEY,
    parentfk text NOT NULL REFERENCES ps_protectedsite ON DELETE CASCADE,
    num integer not null,
    attr_nilreason text,
    attr_xsi_nil boolean,
    ps_designationtype_ps_designationscheme_attr_owns boolean,
    ps_designationtype_ps_designationscheme_attr_nilreason text,
    ps_designationtype_ps_designationscheme_attr_gml_remoteschema text,
    ps_designationtype_ps_designationscheme_fk text,
    ps_designationtype_ps_designationscheme_href text,
    ps_designationtype_ps_designation_attr_owns boolean,
    ps_designationtype_ps_designation_attr_nilreason text,
    ps_designationtype_ps_designation_attr_gml_remoteschema text,
    ps_designationtype_ps_designation_fk text,
    ps_designationtype_ps_designation_href text,
    ps_designationtype_ps_percentageunderdesignation numeric
);
CREATE TABLE ps_protectedsite_ps_sitename (
    id serial PRIMARY KEY,
    parentfk text NOT NULL REFERENCES ps_protectedsite ON DELETE CASCADE,
    num integer not null,
    attr_nilreason text,
    attr_xsi_nil boolean,
    gn_geographicalname_gn_language text,
    gn_geographicalname_gn_language_attr_nilreason text,
    gn_geographicalname_gn_language_attr_xsi_nil boolean,
    gn_geographicalname_gn_nativeness_attr_owns boolean,
    gn_geographicalname_gn_nativeness_attr_nilreason text,
    gn_geographicalname_gn_nativeness_attr_gml_remoteschema text,
    gn_geographicalname_gn_nativeness_attr_xsi_nil boolean,
    gn_geographicalname_gn_nativeness_fk text,
    gn_geographicalname_gn_nativeness_href text,
    gn_geographicalname_gn_namestatus_attr_owns boolean,
    gn_geographicalname_gn_namestatus_attr_nilreason text,
    gn_geographicalname_gn_namestatus_attr_gml_remoteschema text,
    gn_geographicalname_gn_namestatus_attr_xsi_nil boolean,
    gn_geographicalname_gn_namestatus_fk text,
    gn_geographicalname_gn_namestatus_href text,
    gn_geographicalname_gn_sourceofname text,
    gn_geographicalname_gn_sourceofname_attr_nilreason text,
    gn_geographicalname_gn_sourceofname_attr_xsi_nil boolean,
    gn_geographicalname_gn_pronunciation_attr_nilreason text,
    gn_geographicalname_gn_pronunciation_attr_xsi_nil boolean,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_33 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_34 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_35 boolean,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_36 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_37 text,
    gn_geographicalname_gn_pronunciation_gn_pronunciationofna_38 boolean,
    gn_geographicalname_gn_grammaticalgender_attr_owns boolean,
    gn_geographicalname_gn_grammaticalgender_attr_nilreason text,
    gn_geographicalname_gn_grammaticalgender_attr_gml_remoteschema text,
    gn_geographicalname_gn_grammaticalgender_attr_xsi_nil boolean,
    gn_geographicalname_gn_grammaticalgender_fk text,
    gn_geographicalname_gn_grammaticalgender_href text,
    gn_geographicalname_gn_grammaticalnumber_attr_owns boolean,
    gn_geographicalname_gn_grammaticalnumber_attr_nilreason text,
    gn_geographicalname_gn_grammaticalnumber_attr_gml_remoteschema text,
    gn_geographicalname_gn_grammaticalnumber_attr_xsi_nil boolean,
    gn_geographicalname_gn_grammaticalnumber_fk text,
    gn_geographicalname_gn_grammaticalnumber_href text
);
CREATE TABLE ps_protectedsite_ps_sitename_gn_geographicalname_gn_spelling (
    id serial PRIMARY KEY,
    parentfk integer NOT NULL REFERENCES ps_protectedsite_ps_sitename ON DELETE CASCADE,
    num integer not null,
    gn_geographicalname_gn_spellingofname_gn_text text,
    gn_geographicalname_gn_spellingofname_gn_script text,
    gn_geographicalname_gn_spellingofname_gn_script_attr_nilreason text,
    gn_geographicalname_gn_spellingofname_gn_script_attr_xsi_nil boolean,
    gn_geographicalname_gn_spellingofname_gn_transliterationscheme text,
    gn_geographicalname_gn_spellingofname_gn_transliterations_39 text,
    gn_geographicalname_gn_spellingofname_gn_transliterations_40 boolean
);
CREATE TABLE ps_protectedsite_ps_siteprotectionclassification (
    id serial PRIMARY KEY,
    parentfk text NOT NULL REFERENCES ps_protectedsite ON DELETE CASCADE,
    num integer not null,
    value text,
    attr_nilreason text,
    attr_xsi_nil boolean
);