-- as user postgres
CREATE DATABASE cp_blob
  WITH OWNER = deegree
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'en_US.utf8'
       LC_CTYPE = 'en_US.utf8'
       CONNECTION LIMIT = -1;

COMMENT ON DATABASE cp_blob
  IS 'Cadastral parcels - blob schema';

GRANT ALL ON SCHEMA public TO deegree;
GRANT CONNECT ON DATABASE cp_blob TO deegree;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO deegree;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public to deegree;

-- \c cp_blob
CREATE EXTENSION IF NOT EXISTS postgis;